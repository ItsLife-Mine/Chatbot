from flask import Flask, render_template, request
import os
import json
import pickle
import random

app = Flask(__name__)

try:
    current_dir = os.path.dirname(os.path.abspath(__file__))

    intents_path = os.path.join(current_dir, "intents.json")
    if os.path.exists(intents_path):
        with open(intents_path, "r") as f:
            intents = json.load(f)
    else:
        intents = {"intents": []}
        print(f"Warning: {intents_path} not found. Created empty intents.")

    model_path = os.path.join(current_dir, "chatbot_model.pkl")
    if os.path.exists(model_path):
        with open(model_path, "rb") as f:
            model = pickle.load(f)
    else:
        model = None

    vectorizer_path = os.path.join(current_dir, "vectorizer.pkl")
    if os.path.exists(vectorizer_path):
        with open(vectorizer_path, "rb") as f:
            vectorizer = pickle.load(f)
    else:
        vectorizer = None

    tags_path = os.path.join(current_dir, "tags.pkl")
    if os.path.exists(tags_path):
        with open(tags_path, "rb") as f:
            tags = pickle.load(f)
    else:
        tags = None

except Exception as e:
    print(f"Error loading files: {e}")
    intents = {"intents": []}
    model = None
    vectorizer = None
    tags = None

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/get", methods=["POST"])
def chatbot_response():
    msg = request.form["msg"]
    if model is not None and vectorizer is not None:
        X = vectorizer.transform([msg])
        prediction = model.predict(X)[0]
        for intent in intents["intents"]:
            if intent["tag"] == prediction:
                if "responses" in intent and intent["responses"]:
                    return random.choice(intent["responses"])
                else:
                    return "Sorry, I don’t have a response for that."
    return "Sorry, I didn't understand that. Please try again."

if __name__ == "__main__":
    app.run(debug=True)